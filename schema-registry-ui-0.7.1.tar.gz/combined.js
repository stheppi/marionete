'use strict';

var angularAPP = angular.module('angularAPP', [
  'ui.ace',
  'angularSpinner',
  'angularUtils.directives.dirPagination',
  'ngRoute',
  'ngMaterial',
  'ngAnimate',
  'ngAria',
  'md.data.table',
  'diff-match-patch'
]);

angularAPP.controller('MenuCtrl', function ($scope, $log) {
});

angularAPP.config(function ($routeProvider) {
  $routeProvider
    .when('/', {
      templateUrl: 'src/schema-registry/home/home.html',
      controller: 'HomeCtrl'
    })
    .when('/schema/new', {
      templateUrl: 'src/schema-registry/new/new.html',
      controller: 'NewSubjectCtrl as ctrl'
    })
    .when('/schema/:subject/version/:version', {
      templateUrl: 'src/schema-registry/view/view.html',
      controller: 'SubjectsCtrl'
    }).otherwise({
    redirectTo: '/'
  });
  // $locationProvider.html5Mode(true);
});

angularAPP.config(function ($mdThemingProvider) {
  $mdThemingProvider.theme('default')
    .primaryPalette('blue-grey')
    .accentPalette('blue')
    .warnPalette('grey');
});

angularAPP.filter('reverse', function() {
  return function(items) {
    return items.slice().reverse();
  };
});

// Schema Registry service URL (i.e. http://localhost:8081)
var SCHEMA_REGISTRY = "http://localhost:8081"; // https://schema-registry.demo.landoop.com

// Avro4S backend url. Allows converting Avro -> Scala Case classes
var AVRO4S = "https://platform.landoop.com/avro4s/avro4s";


angularAPP.factory('Avro4ScalaFactory', function ($rootScope, $http, $location, $q, $log) {

  /* Public API */
  return {
    getScalaFiles: function (apiData) {
      $log.warn(apiData);
      $http.defaults.useXDomain = true;

      var singleLineApiData = apiData.split("\n").join(" ");

      var req = {
        method: 'POST',
        data: singleLineApiData,
        crossDomain: true,
        url: AVRO4S,
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
      };

      $http(req)
        .success(function (data) {
          $log.info("Received a response with: " + data);
          var results = data.split("###");
          $log.info(results);
          if (results[0] == "scala") {
            $log.info("It's Scala !! ");
            $log.info("It's Scala :" + results[1]);
            //alg0
            var scalaResult = results[1];
            return scalaResult;
          }
        })
        .error(function (data, status) {
          $log.error("Bad data [" + data + "] status [" + status + "]");
        });
    }
  }
});

// curl 'https://platform.landoop.com/avro4s/avro4s' -H 'Pragma: no-cache' -H 'Origin: https://avro4s-ui.landoop.com' -H 'Accept-Encoding: gzip, deflate, br' -H 'Accept-Language: en-US,en;q=0.8,el;q=0.6' -H 'User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.106 Safari/537.36' -H 'Content-Type: application/json' -H 'Accept: application/json' -H 'Cache-Control: no-cache' -H 'Referer: https://avro4s-ui.landoop.com/' -H 'Connection: keep-alive' --data-binary '{   "type": "record",   "name": "Evolution",   "namespace": "com.landoop",   "fields": [     {         "name": "name",         "type": "string"     },     {         "name": "number1",         "type": "int"     },     {         "name": "number2",         "type": "float"     },     {         "name": "text",         "type": [             "string",             "null"         ],         "default": ""     }   ] }' --compressed
/**
 * dirPagination - AngularJS module for paginating (almost) anything.
 *
 *
 * Credits
 * =======
 *
 * Daniel Tabuenca: https://groups.google.com/d/msg/angular/an9QpzqIYiM/r8v-3W1X5vcJ
 * for the idea on how to dynamically invoke the ng-repeat directive.
 *
 * I borrowed a couple of lines and a few attribute names from the AngularUI Bootstrap project:
 * https://github.com/angular-ui/bootstrap/blob/master/src/pagination/pagination.js
 *
 * Copyright 2014 Michael Bromley <michael@michaelbromley.co.uk>
 *
 * @antonios 18-Aug-16 enhanced this with a material-design pagination template
 */

(function () {

  /**
   * Config
   */
  var moduleName = 'angularUtils.directives.dirPagination';
  var DEFAULT_ID = '__default';

  /**
   * Module
   */
  angular.module(moduleName, [])
    .directive('dirPaginate', ['$compile', '$parse', 'paginationService', dirPaginateDirective])
    .directive('dirPaginateNoCompile', noCompileDirective)
    .directive('dirPaginationControls', ['paginationService', 'paginationTemplate', dirPaginationControlsDirective])
    .filter('itemsPerPage', ['paginationService', itemsPerPageFilter])
    .service('paginationService', paginationService)
    .provider('paginationTemplate', paginationTemplateProvider)
    .run(['$templateCache', dirPaginationControlsTemplateInstaller]);

  function dirPaginateDirective($compile, $parse, paginationService) {

    return {
      terminal: true,
      multiElement: true,
      priority: 100,
      compile: dirPaginationCompileFn
    };

    function dirPaginationCompileFn(tElement, tAttrs) {

      var expression = tAttrs.dirPaginate;
      // regex taken directly from https://github.com/angular/angular.js/blob/v1.4.x/src/ng/directive/ngRepeat.js#L339
      var match = expression.match(/^\s*([\s\S]+?)\s+in\s+([\s\S]+?)(?:\s+as\s+([\s\S]+?))?(?:\s+track\s+by\s+([\s\S]+?))?\s*$/);

      var filterPattern = /\|\s*itemsPerPage\s*:\s*(.*\(\s*\w*\)|([^\)]*?(?=\s+as\s+))|[^\)]*)/;
      if (match[2].match(filterPattern) === null) {
        throw 'pagination directive: the \'itemsPerPage\' filter must be set.';
      }
      var itemsPerPageFilterRemoved = match[2].replace(filterPattern, '');
      var collectionGetter = $parse(itemsPerPageFilterRemoved);

      addNoCompileAttributes(tElement);

      // If any value is specified for paginationId, we register the un-evaluated expression at this stage for the benefit of any
      // dir-pagination-controls directives that may be looking for this ID.
      var rawId = tAttrs.paginationId || DEFAULT_ID;
      paginationService.registerInstance(rawId);

      return function dirPaginationLinkFn(scope, element, attrs) {

        // Now that we have access to the `scope` we can interpolate any expression given in the paginationId attribute and
        // potentially register a new ID if it evaluates to a different value than the rawId.
        var paginationId = $parse(attrs.paginationId)(scope) || attrs.paginationId || DEFAULT_ID;

        // (TODO: this seems sound, but I'm reverting as many bug reports followed it's introduction in 0.11.0.
        // Needs more investigation.)
        // In case rawId != paginationId we deregister using rawId for the sake of general cleanliness
        // before registering using paginationId
        // paginationService.deregisterInstance(rawId);
        paginationService.registerInstance(paginationId);

        var repeatExpression = getRepeatExpression(expression, paginationId);
        addNgRepeatToElement(element, attrs, repeatExpression);

        removeTemporaryAttributes(element);
        var compiled = $compile(element);

        var currentPageGetter = makeCurrentPageGetterFn(scope, attrs, paginationId);
        paginationService.setCurrentPageParser(paginationId, currentPageGetter, scope);

        if (typeof attrs.totalItems !== 'undefined') {
          paginationService.setAsyncModeTrue(paginationId);
          scope.$watch(function () {
            return $parse(attrs.totalItems)(scope);
          }, function (result) {
            if (0 <= result) {
              paginationService.setCollectionLength(paginationId, result);
            }
          });
        } else {
          paginationService.setAsyncModeFalse(paginationId);
          scope.$watchCollection(function () {
            return collectionGetter(scope);
          }, function (collection) {
            if (collection) {
              var collectionLength = (collection instanceof Array) ? collection.length : Object.keys(collection).length;
              paginationService.setCollectionLength(paginationId, collectionLength);
            }
          });
        }

        // Delegate to the link function returned by the new compilation of the ng-repeat
        compiled(scope);

        // (TODO: Reverting this due to many bug reports in v 0.11.0. Needs investigation as the
        // principle is sound)
        // When the scope is destroyed, we make sure to remove the reference to it in paginationService
        // so that it can be properly garbage collected
        // scope.$on('$destroy', function destroyDirPagination() {
        //     paginationService.deregisterInstance(paginationId);
        // });
      };
    }

    /**
     * If a pagination id has been specified, we need to check that it is present as the second argument passed to
     * the itemsPerPage filter. If it is not there, we add it and return the modified expression.
     *
     * @param expression
     * @param paginationId
     * @returns {*}
     */
    function getRepeatExpression(expression, paginationId) {
      var repeatExpression,
        idDefinedInFilter = !!expression.match(/(\|\s*itemsPerPage\s*:[^|]*:[^|]*)/);

      if (paginationId !== DEFAULT_ID && !idDefinedInFilter) {
        repeatExpression = expression.replace(/(\|\s*itemsPerPage\s*:\s*[^|\s]*)/, "$1 : '" + paginationId + "'");
      } else {
        repeatExpression = expression;
      }

      return repeatExpression;
    }

    /**
     * Adds the ng-repeat directive to the element. In the case of multi-element (-start, -end) it adds the
     * appropriate multi-element ng-repeat to the first and last element in the range.
     * @param element
     * @param attrs
     * @param repeatExpression
     */
    function addNgRepeatToElement(element, attrs, repeatExpression) {
      if (element[0].hasAttribute('dir-paginate-start') || element[0].hasAttribute('data-dir-paginate-start')) {
        // using multiElement mode (dir-paginate-start, dir-paginate-end)
        attrs.$set('ngRepeatStart', repeatExpression);
        element.eq(element.length - 1).attr('ng-repeat-end', true);
      } else {
        attrs.$set('ngRepeat', repeatExpression);
      }
    }

    /**
     * Adds the dir-paginate-no-compile directive to each element in the tElement range.
     * @param tElement
     */
    function addNoCompileAttributes(tElement) {
      angular.forEach(tElement, function (el) {
        if (el.nodeType === 1) {
          angular.element(el).attr('dir-paginate-no-compile', true);
        }
      });
    }

    /**
     * Removes the variations on dir-paginate (data-, -start, -end) and the dir-paginate-no-compile directives.
     * @param element
     */
    function removeTemporaryAttributes(element) {
      angular.forEach(element, function (el) {
        if (el.nodeType === 1) {
          angular.element(el).removeAttr('dir-paginate-no-compile');
        }
      });
      element.eq(0).removeAttr('dir-paginate-start').removeAttr('dir-paginate').removeAttr('data-dir-paginate-start').removeAttr('data-dir-paginate');
      element.eq(element.length - 1).removeAttr('dir-paginate-end').removeAttr('data-dir-paginate-end');
    }

    /**
     * Creates a getter function for the current-page attribute, using the expression provided or a default value if
     * no current-page expression was specified.
     *
     * @param scope
     * @param attrs
     * @param paginationId
     * @returns {*}
     */
    function makeCurrentPageGetterFn(scope, attrs, paginationId) {
      var currentPageGetter;
      if (attrs.currentPage) {
        currentPageGetter = $parse(attrs.currentPage);
      } else {
        // If the current-page attribute was not set, we'll make our own.
        // Replace any non-alphanumeric characters which might confuse
        // the $parse service and give unexpected results.
        // See https://github.com/michaelbromley/angularUtils/issues/233
        var defaultCurrentPage = (paginationId + '__currentPage').replace(/\W/g, '_');
        scope[defaultCurrentPage] = 1;
        currentPageGetter = $parse(defaultCurrentPage);
      }
      return currentPageGetter;
    }
  }

  /**
   * This is a helper directive that allows correct compilation when in multi-element mode (ie dir-paginate-start, dir-paginate-end).
   * It is dynamically added to all elements in the dir-paginate compile function, and it prevents further compilation of
   * any inner directives. It is then removed in the link function, and all inner directives are then manually compiled.
   */
  function noCompileDirective() {
    return {
      priority: 5000,
      terminal: true
    };
  }

  function dirPaginationControlsTemplateInstaller($templateCache) {
    var strVar = "";
    strVar += "<section style=\"margin: 5px 10px 0;\" layout=\"row\" layout-align=\"center\" ng-if=\"1 < pages.length || !autoHide\" class=\"pagination\"> <md-button aria-label=\"Previous page\" ng-if=\"boundaryLinks\" ng-disabled=\"pagination.current===1\" ng-click=\"setCurrent(1)\"> <ng-md-icon icon=\"first_page\"><\/ng-md-icon> <\/md-button> <md-button aria-label=\"First page\" ng-if=\"directionLinks\" ng-disabled=\"pagination.current===1\" ng-click=\"setCurrent(pagination.current - 1)\"> <ng-md-icon class=\"fa fa-chevron-left\"><\/ng-md-icon> <\/md-button> <md-button ng-repeat=\"pageNumber in pages track by tracker(pageNumber, $index)\" ng-class=\"{'md-primary' : pagination.current==pageNumber}\" ng-disabled=\"pageNumber==='...'\" ng-click=\"setCurrent(pageNumber)\">{{pageNumber}}<\/md-button> <md-button aria-label=\"Last page\" ng-if=\"directionLinks\" ng-disabled=\"pagination.current===pagination.last\" ng-click=\"setCurrent(pagination.current + 1)\"> <ng-md-icon class=\"fa fa-chevron-right\"><\/ng-md-icon> <\/md-button> <md-button ng-if=\"boundaryLinks\" ng-disabled=\"pagination.current===pagination.last\" ng-click=\"setCurrent(pagination.last)\"> <ng-md-icon icon=\"last_page\"><\/ng-md-icon> <\/md-button><\/section>";

    $templateCache.put('angularUtils.directives.dirPagination.template', strVar);
  }

  function dirPaginationControlsDirective(paginationService, paginationTemplate) {

    var numberRegex = /^\d+$/;

    var DDO = {
      restrict: 'AE',
      scope: {
        maxSize: '=?',
        onPageChange: '&?',
        paginationId: '=?',
        autoHide: '=?'
      },
      link: dirPaginationControlsLinkFn
    };

    // We need to check the paginationTemplate service to see whether a template path or
    // string has been specified, and add the `template` or `templateUrl` property to
    // the DDO as appropriate. The order of priority to decide which template to use is
    // (highest priority first):
    // 1. paginationTemplate.getString()
    // 2. attrs.templateUrl
    // 3. paginationTemplate.getPath()
    var templateString = paginationTemplate.getString();
    if (templateString !== undefined) {
      DDO.template = templateString;
    } else {
      DDO.templateUrl = function (elem, attrs) {
        return attrs.templateUrl || paginationTemplate.getPath();
      };
    }
    return DDO;

    function dirPaginationControlsLinkFn(scope, element, attrs) {

      // rawId is the un-interpolated value of the pagination-id attribute. This is only important when the corresponding dir-paginate directive has
      // not yet been linked (e.g. if it is inside an ng-if block), and in that case it prevents this controls directive from assuming that there is
      // no corresponding dir-paginate directive and wrongly throwing an exception.
      var rawId = attrs.paginationId || DEFAULT_ID;
      var paginationId = scope.paginationId || attrs.paginationId || DEFAULT_ID;

      if (!paginationService.isRegistered(paginationId) && !paginationService.isRegistered(rawId)) {
        var idMessage = (paginationId !== DEFAULT_ID) ? ' (id: ' + paginationId + ') ' : ' ';
        if (window.console) {
          console.warn('Pagination directive: the pagination controls' + idMessage + 'cannot be used without the corresponding pagination directive, which was not found at link time.');
        }
      }

      if (!scope.maxSize) {
        scope.maxSize = 9;
      }
      scope.autoHide = scope.autoHide === undefined ? true : scope.autoHide;
      scope.directionLinks = angular.isDefined(attrs.directionLinks) ? scope.$parent.$eval(attrs.directionLinks) : true;
      scope.boundaryLinks = angular.isDefined(attrs.boundaryLinks) ? scope.$parent.$eval(attrs.boundaryLinks) : false;

      var paginationRange = Math.max(scope.maxSize, 5);
      scope.pages = [];
      scope.pagination = {
        last: 1,
        current: 1
      };
      scope.range = {
        lower: 1,
        upper: 1,
        total: 1
      };

      scope.$watch('maxSize', function (val) {
        if (val) {
          paginationRange = Math.max(scope.maxSize, 5);
          generatePagination();
        }
      });

      scope.$watch(function () {
        if (paginationService.isRegistered(paginationId)) {
          return (paginationService.getCollectionLength(paginationId) + 1) * paginationService.getItemsPerPage(paginationId);
        }
      }, function (length) {
        if (0 < length) {
          generatePagination();
        }
      });

      scope.$watch(function () {
        if (paginationService.isRegistered(paginationId)) {
          return (paginationService.getItemsPerPage(paginationId));
        }
      }, function (current, previous) {
        if (current != previous && typeof previous !== 'undefined') {
          goToPage(scope.pagination.current);
        }
      });

      scope.$watch(function () {
        if (paginationService.isRegistered(paginationId)) {
          return paginationService.getCurrentPage(paginationId);
        }
      }, function (currentPage, previousPage) {
        if (currentPage != previousPage) {
          goToPage(currentPage);
        }
      });

      scope.setCurrent = function (num) {
        if (paginationService.isRegistered(paginationId) && isValidPageNumber(num)) {
          num = parseInt(num, 10);
          paginationService.setCurrentPage(paginationId, num);
        }
      };

      /**
       * Custom "track by" function which allows for duplicate "..." entries on long lists,
       * yet fixes the problem of wrongly-highlighted links which happens when using
       * "track by $index" - see https://github.com/michaelbromley/angularUtils/issues/153
       * @param id
       * @param index
       * @returns {string}
       */
      scope.tracker = function (id, index) {
        return id + '_' + index;
      };

      function goToPage(num) {
        if (paginationService.isRegistered(paginationId) && isValidPageNumber(num)) {
          var oldPageNumber = scope.pagination.current;

          scope.pages = generatePagesArray(num, paginationService.getCollectionLength(paginationId), paginationService.getItemsPerPage(paginationId), paginationRange);
          scope.pagination.current = num;
          updateRangeValues();

          // if a callback has been set, then call it with the page number as the first argument
          // and the previous page number as a second argument
          if (scope.onPageChange) {
            scope.onPageChange({
              newPageNumber: num,
              oldPageNumber: oldPageNumber
            });
          }
        }
      }

      function generatePagination() {
        if (paginationService.isRegistered(paginationId)) {
          var page = parseInt(paginationService.getCurrentPage(paginationId)) || 1;
          scope.pages = generatePagesArray(page, paginationService.getCollectionLength(paginationId), paginationService.getItemsPerPage(paginationId), paginationRange);
          scope.pagination.current = page;
          scope.pagination.last = scope.pages[scope.pages.length - 1];
          if (scope.pagination.last < scope.pagination.current) {
            scope.setCurrent(scope.pagination.last);
          } else {
            updateRangeValues();
          }
        }
      }

      /**
       * This function updates the values (lower, upper, total) of the `scope.range` object, which can be used in the pagination
       * template to display the current page range, e.g. "showing 21 - 40 of 144 results";
       */
      function updateRangeValues() {
        if (paginationService.isRegistered(paginationId)) {
          var currentPage = paginationService.getCurrentPage(paginationId),
            itemsPerPage = paginationService.getItemsPerPage(paginationId),
            totalItems = paginationService.getCollectionLength(paginationId);

          scope.range.lower = (currentPage - 1) * itemsPerPage + 1;
          scope.range.upper = Math.min(currentPage * itemsPerPage, totalItems);
          scope.range.total = totalItems;
        }
      }

      function isValidPageNumber(num) {
        return (numberRegex.test(num) && (0 < num && num <= scope.pagination.last));
      }
    }

    /**
     * Generate an array of page numbers (or the '...' string) which is used in an ng-repeat to generate the
     * links used in pagination
     *
     * @param currentPage
     * @param rowsPerPage
     * @param paginationRange
     * @param collectionLength
     * @returns {Array}
     */
    function generatePagesArray(currentPage, collectionLength, rowsPerPage, paginationRange) {
      var pages = [];
      var totalPages = Math.ceil(collectionLength / rowsPerPage);
      var halfWay = Math.ceil(paginationRange / 2);
      var position;

      if (currentPage <= halfWay) {
        position = 'start';
      } else if (totalPages - halfWay < currentPage) {
        position = 'end';
      } else {
        position = 'middle';
      }

      var ellipsesNeeded = paginationRange < totalPages;
      var i = 1;
      while (i <= totalPages && i <= paginationRange) {
        var pageNumber = calculatePageNumber(i, currentPage, paginationRange, totalPages);

        var openingEllipsesNeeded = (i === 2 && (position === 'middle' || position === 'end'));
        var closingEllipsesNeeded = (i === paginationRange - 1 && (position === 'middle' || position === 'start'));
        if (ellipsesNeeded && (openingEllipsesNeeded || closingEllipsesNeeded)) {
          pages.push('...');
        } else {
          pages.push(pageNumber);
        }
        i++;
      }
      return pages;
    }

    /**
     * Given the position in the sequence of pagination links [i], figure out what page number corresponds to that position.
     *
     * @param i
     * @param currentPage
     * @param paginationRange
     * @param totalPages
     * @returns {*}
     */
    function calculatePageNumber(i, currentPage, paginationRange, totalPages) {
      var halfWay = Math.ceil(paginationRange / 2);
      if (i === paginationRange) {
        return totalPages;
      } else if (i === 1) {
        return i;
      } else if (paginationRange < totalPages) {
        if (totalPages - halfWay < currentPage) {
          return totalPages - paginationRange + i;
        } else if (halfWay < currentPage) {
          return currentPage - halfWay + i;
        } else {
          return i;
        }
      } else {
        return i;
      }
    }
  }

  /**
   * This filter slices the collection into pages based on the current page number and number of items per page.
   * @param paginationService
   * @returns {Function}
   */
  function itemsPerPageFilter(paginationService) {

    return function (collection, itemsPerPage, paginationId) {
      if (typeof (paginationId) === 'undefined') {
        paginationId = DEFAULT_ID;
      }
      if (!paginationService.isRegistered(paginationId)) {
        throw 'pagination directive: the itemsPerPage id argument (id: ' + paginationId + ') does not match a registered pagination-id.';
      }
      var end;
      var start;
      if (angular.isObject(collection)) {
        itemsPerPage = parseInt(itemsPerPage) || 9999999999;
        if (paginationService.isAsyncMode(paginationId)) {
          start = 0;
        } else {
          start = (paginationService.getCurrentPage(paginationId) - 1) * itemsPerPage;
        }
        end = start + itemsPerPage;
        paginationService.setItemsPerPage(paginationId, itemsPerPage);

        if (collection instanceof Array) {
          // the array just needs to be sliced
          return collection.slice(start, end);
        } else {
          // in the case of an object, we need to get an array of keys, slice that, then map back to
          // the original object.
          var slicedObject = {};
          angular.forEach(keys(collection).slice(start, end), function (key) {
            slicedObject[key] = collection[key];
          });
          return slicedObject;
        }
      } else {
        return collection;
      }
    };
  }

  /**
   * Shim for the Object.keys() method which does not exist in IE < 9
   * @param obj
   * @returns {Array}
   */
  function keys(obj) {
    if (!Object.keys) {
      var objKeys = [];
      for (var i in obj) {
        if (obj.hasOwnProperty(i)) {
          objKeys.push(i);
        }
      }
      return objKeys;
    } else {
      return Object.keys(obj);
    }
  }

  /**
   * This service allows the various parts of the module to communicate and stay in sync.
   */
  function paginationService() {

    var instances = {};
    var lastRegisteredInstance;

    this.registerInstance = function (instanceId) {
      if (typeof instances[instanceId] === 'undefined') {
        instances[instanceId] = {
          asyncMode: false
        };
        lastRegisteredInstance = instanceId;
      }
    };

    this.deregisterInstance = function (instanceId) {
      delete instances[instanceId];
    };

    this.isRegistered = function (instanceId) {
      return (typeof instances[instanceId] !== 'undefined');
    };

    this.getLastInstanceId = function () {
      return lastRegisteredInstance;
    };

    this.setCurrentPageParser = function (instanceId, val, scope) {
      instances[instanceId].currentPageParser = val;
      instances[instanceId].context = scope;
    };
    this.setCurrentPage = function (instanceId, val) {
      instances[instanceId].currentPageParser.assign(instances[instanceId].context, val);
    };
    this.getCurrentPage = function (instanceId) {
      var parser = instances[instanceId].currentPageParser;
      return parser ? parser(instances[instanceId].context) : 1;
    };

    this.setItemsPerPage = function (instanceId, val) {
      instances[instanceId].itemsPerPage = val;
    };
    this.getItemsPerPage = function (instanceId) {
      return instances[instanceId].itemsPerPage;
    };

    this.setCollectionLength = function (instanceId, val) {
      instances[instanceId].collectionLength = val;
    };
    this.getCollectionLength = function (instanceId) {
      return instances[instanceId].collectionLength;
    };

    this.setAsyncModeTrue = function (instanceId) {
      instances[instanceId].asyncMode = true;
    };

    this.setAsyncModeFalse = function (instanceId) {
      instances[instanceId].asyncMode = false;
    };

    this.isAsyncMode = function (instanceId) {
      return instances[instanceId].asyncMode;
    };
  }

  /**
   * This provider allows global configuration of the template path used by the dir-pagination-controls directive.
   */
  function paginationTemplateProvider() {

    var templatePath = 'angularUtils.directives.dirPagination.template';
    var templateString;

    /**
     * Set a templateUrl to be used by all instances of <dir-pagination-controls>
     * @param {String} path
     */
    this.setPath = function (path) {
      templatePath = path;
    };

    /**
     * Set a string of HTML to be used as a template by all instances
     * of <dir-pagination-controls>. If both a path *and* a string have been set,
     * the string takes precedence.
     * @param {String} str
     */
    this.setString = function (str) {
      templateString = str;
    };

    this.$get = function () {
      return {
        getPath: function () {
          return templatePath;
        },
        getString: function () {
          return templateString;
        }
      };
    };
  }
})();

/**
 * Schema-Registry angularJS Factory
 * version 0.7 (16.Aug.2016)
 *
 * @author antonios@landoop.com
 */
angularAPP.factory('SchemaRegistryFactory', function ($rootScope, $http, $location, $q, $log, UtilsFactory) {

  /**
   * Get subjects
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#get--subjects
   */
  function getSubjects() {

    var url = SCHEMA_REGISTRY + '/subjects/';
    $log.debug("  curl -X GET " + url);
    var start = new Date().getTime();

    var deferred = $q.defer();
    $http.get(url)
      .then(
        function successCallback(response) {
          var allSubjectNames = response.data;
          $log.debug("  curl -X GET " + url + " => " + allSubjectNames.length + " registered subjects in [ " + ((new Date().getTime()) - start) + " ] msec");
          deferred.resolve(allSubjectNames);
        },
        function errorCallback(response) {
          deferred.reject("Failure with : " + response)
        });

    return deferred.promise;
  }

  /**
   * Get subjects versions
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#get--subjects-(string- subject)-versions
   */
  function getSubjectsVersions(subjectName) {

    var url = SCHEMA_REGISTRY + '/subjects/' + subjectName + '/versions/';
    $log.debug("  curl -X GET " + url);
    var start = new Date().getTime();

    var deferred = $q.defer();
    $http.get(url).then(
      function successCallback(response) {
        var allVersions = response.data;
        $log.debug("  curl -X GET " + url + " => " + JSON.stringify(allVersions) + " versions in [ " + (new Date().getTime() - start) + " ] msec");
        deferred.resolve(allVersions);
      },
      function errorCallback(response) {
        var msg = "Failure with : " + response + " " + JSON.stringify(response);
        $log.error("Error in getting subject versions : " + msg);
        deferred.reject(msg);
      });

    return deferred.promise;

  }

  /**
   * Get a specific version of the schema registered under this subject
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#get--subjects-(string- subject)-versions-(versionId- version)
   */
  function getSubjectAtVersion(subjectName, version) {

    var url = SCHEMA_REGISTRY + '/subjects/' + subjectName + '/versions/' + version;
    $log.debug("  curl -X GET " + url);

    var deferred = $q.defer();
    var start = new Date().getTime();
    $http.get(url).then(
      function successCallback(response) {
        var subjectInformation = response.data;
        $log.debug("  curl -X GET " + url + " => [" + subjectName + "] subject " + JSON.stringify(subjectInformation).length + " bytes in [ " + (new Date().getTime() - start) + " ] msec");
        deferred.resolve(subjectInformation);
      },
      function errorCallback(response) {
        var msg = "Failure getting subject at version : " + response + " " + JSON.stringify(response);
        $log.error(msg);
        deferred.reject(msg);
      });

    return deferred.promise;

  }

  /**
   * Register a new schema under the specified subject. If successfully registered, this returns the unique identifier of this schema in the registry.
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#post--subjects-(string- subject)-versions
   */
  function postNewSubjectVersion(subjectName, newSchema) {

    var deferred = $q.defer();
    $log.debug("Posting new version of subject [" + subjectName + "]");

    var postSchemaRegistration = {
      method: 'POST',
      url: SCHEMA_REGISTRY + '/subjects/' + subjectName + "/versions",
      data: '{"schema":"' + newSchema.replace(/\n/g, " ").replace(/\s\s+/g, ' ').replace(/"/g, "\\\"") + '"}' + "'",
      dataType: 'json',
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
    };

    $http(postSchemaRegistration)
      .success(function (data) {
        //$log.info("Success in registering new schema " + JSON.stringify(data));
        var schemaId = data.id;
        deferred.resolve(schemaId);
      })
      .error(function (data, status) {
        $log.info("Error on schema registration : " + JSON.stringify(data));
        var errorMessage = data.message;
        if (status >= 400) {
          $log.debug("Schema registrations is not allowed " + status + " " + data);
        } else {
          $log.debug("Schema registration failure: " + JSON.stringify(data));
        }
        deferred.reject(data);
      });

    return deferred.promise;

  }

  /**
   * Check if a schema has already been registered under the specified subject. If so, this returns the schema string
   * along with its globally unique identifier, its version under this subject and the subject name.
   *
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#post--subjects-(string- subject)
   */
  function checkSchemaExists(subjectName, subjectInformation) {

    var deferred = $q.defer();
    $log.debug("Checking if schema exists under this subject [" + subjectName + "]");

    var postSchemaExists = {
      method: 'POST',
      url: SCHEMA_REGISTRY + '/subjects/' + subjectName,
      data: '{"schema":"' + subjectInformation.replace(/\n/g, " ").replace(/\s\s+/g, ' ').replace(/"/g, "\\\"") + '"}' + "'",
      dataType: 'json',
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
    };

    $http(postSchemaExists)
      .success(function (data) {
        var response = {
          id: data.id,
          version: data.version
        };
        $log.info("Response : " + JSON.stringify(response));
        deferred.resolve(response);
      })
      .error(function (data, status) {
        $log.info("Error while checking if schema exists under a subject : " + JSON.stringify(data));
        var errorMessage = data.message;
        if (status == 407) {
          $log.debug("Subject not found or schema not found - 407 - " + status + " " + data);
        } else {
          $log.debug("Some other failure: " + JSON.stringify(data));
        }
        $defered.reject("Something")
      });

    return deferred.promise;

  }

  /**
   * Test input schema against a particular version of a subject’s schema for compatibility.
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#post--compatibility-subjects-(string- subject)-versions-(versionId- version)
   */
  function testSchemaCompatibility(subjectName, subjectInformation) {

    var deferred = $q.defer();
    $log.debug("  Testing schema compatibility for [" + subjectName + "]");

    var postCompatibility = {
      method: 'POST',
      url: SCHEMA_REGISTRY + '/compatibility/subjects/' + subjectName + "/versions/latest",
      data: '{"schema":"' + subjectInformation.replace(/\n/g, " ").replace(/\s\s+/g, ' ').replace(/"/g, "\\\"") + '"}' + "'",
      dataType: 'json',
      headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
    };

    $http(postCompatibility)
      .success(function (data) {
        $log.info("Success in testing schema compatibility " + JSON.stringify(data));
        deferred.resolve(data.is_compatible)
      })
      .error(function (data, status) {
        $log.warn("Error on check compatibility : " + JSON.stringify(data));
        if (status == 404) {
          if (data.error_code == 40401) {
            $log.warn("40401 = Subject not found");
          }
          $log.warn("[" + subjectName + "] is a non existing subject");
          deferred.resolve("new"); // This will be a new subject (!)
        } else {
          $log.error("HTTP > 200 && < 400 (!) " + JSON.stringify(data));
        }
        deferred.reject(data);
      });

    return deferred.promise;

  }

  /**
   * Put global config (Test input schema against a particular version of a subject’s schema for compatibility.
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#put--config
   */
  function putConfig(compatibilityLevel) {

    var deferred = $q.defer();

    if (["NONE", "FULL", "FORWARD", "BACKWARD"].instanceOf(compatibilityLevel) != -1) {

      var postConfig = {
        method: 'POST',
        url: SCHEMA_REGISTRY + '/config',
        data: '{"compatibility":"' + compatibilityLevel + '"}' + "'",
        dataType: 'json',
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
      };

      $http(postConfig)
        .success(function (data) {
          $log.info("Success in changing global schema-registry compatibility " + JSON.stringify(data));
          deferred.resolve(data.compatibility)
        })
        .error(function (data, status) {
          $log.info("Error on changing global compatibility : " + JSON.stringify(data));
          if (status == 422) {
            $log.warn("Invalid compatibility level " + JSON.stringify(status) + " " + JSON.stringify(data));
            if (JSON.stringify(data).indexOf('50001') > -1) {
              $log.error(" Error in the backend data store - " + $scope.text);
            } else if (JSON.stringify(data).indexOf('50003') > -1) {
              $log.error("Error while forwarding the request to the master: " + JSON.stringify(data));
            }
          } else {
            $log.debug("HTTP > 200 && < 400 (!) " + JSON.stringify(data));
          }
          deferred.reject(data);
        });

    } else {
      $log.warn("Compatibility level:" + compatibilityLevel + " is not supported");
      deferred.reject();
    }

    return deferred.promise;

  }

  /**
   * Get global compatibility-level config
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#get--config
   */
  function getGlobalConfig() {

    var deferred = $q.defer();
    var url = SCHEMA_REGISTRY + '/config';
    $log.debug("  curl -X GET " + url);
    var start = new Date().getTime();
    $http.get(url)
      .success(function (data) {
        $log.debug("  curl -X GET " + url + " => in [ " + ((new Date().getTime()) - start) + "] msec");
        deferred.resolve(data)
      })
      .error(function (data, status) {
        deferred.reject("Get global config rejection : " + data + " " + status)
      });

    return deferred.promise;

  }

  /**
   * Update compatibility level for the specified subject
   * @see http://docs.confluent.io/3.0.0/schema-registry/docs/api.html#put--config-(string- subject)
   */
  function updateSubjectCompatibility(subjectName, newCompatibilityLevel) {

    var deferred = $q.defer();

    if (["NONE", "FULL", "FORWARD", "BACKWARD"].instanceOf(newCompatibilityLevel) != -1) {

      var postConfig = {
        method: 'POST',
        url: SCHEMA_REGISTRY + '/config/' + subjectName,
        data: '{"compatibility":"' + newCompatibilityLevel + '"}' + "'",
        dataType: 'json',
        headers: {'Content-Type': 'application/json', 'Accept': 'application/json'}
      };

      $http(postConfig)
        .success(function (data) {
          $log.info("Success in changing subject [ " + subjectName + " ] compatibility " + JSON.stringify(data));
          deferred.resolve(data.compatibility)
        })
        .error(function (data, status) {
          $log.info("Error on changing compatibility : " + JSON.stringify(data));
          if (status == 422) {
            $log.warn("Invalid compatibility level " + JSON.stringify(status) + " " + JSON.stringify(data));
            if (JSON.stringify(data).indexOf('50001') > -1) {
              $log.error(" Error in the backend data store - " + $scope.text);
            } else if (JSON.stringify(data).indexOf('50003') > -1) {
              $log.error("Error while forwarding the request to the master: " + JSON.stringify(data));
            }
          } else {
            $log.debug("HTTP > 200 && < 400 (!) " + JSON.stringify(data));
          }
          deferred.reject(data);
        });

    } else {
      $log.warn("Compatibility level:" + compatibilityLevel + " is not supported");
      deferred.reject();
    }

    return deferred.promise;

  }


  /**
   * Custom logic of Factory is implemented here.
   *
   * In a nut-shell `CACHE` is holding a cache of known subjects
   * Methods here are utilizing the cache - picking from it or updating
   *
   * Subjects are immutable in the schema-registry, thus downloading them
   * just once is enough !
   */

  var CACHE = []; // A cache of the latest subject

  /**
   * Gets from CACHE if exists - undefined otherwise
   */
  function getFromCache(subjectName, subjectVersion) {
    var start = new Date().getTime();
    var response = undefined;
    angular.forEach(CACHE, function (subject) {
      if (subject.subjectName == subjectName && subject.version == subjectVersion) {
        $log.debug("  [ " + subjectName + "/" + subjectVersion + " ] found in cache " + JSON.stringify(subject).length + " bytes in [ " + ((new Date().getTime()) - start) + " ] msec");
        response = subject;
      }
    });
    return response;
  }

  /**
   * GETs latest from CACHE or 'undefined'
   */
  function getLatestFromCache(subjectName) {
    var subjectFromCache = undefined;
    for (var i = 1; i < 10000; i++) {
      var x = getFromCache(subjectName, i);
      if (x != undefined)
        subjectFromCache = x;
    }
    return subjectFromCache;
  }


  /**
   *
   * Composite & Public Methods of this factory
   *
   */
  return {

    // Proxy in function
    getGlobalConfig: function () {
      return getGlobalConfig();
    },

    // Proxy in function
    testSchemaCompatibility: function (subjectName, subjectInformation) {
      return testSchemaCompatibility(subjectName, subjectInformation);
    },

    // Proxy in function
    registerNewSchema: function (subjectName, subjectInformation) {
      return postNewSubjectVersion(subjectName, subjectInformation);
    },

    // Proxy in function
    getSubjectsVersions: function (subjectName) {
      return getSubjectsVersions(subjectName);
    },

    // Proxy in function
    getLatestSubjectFromCache: function (subjectName) {
      return getLatestFromCache(subjectName);
    },

    /**
     * GETs all subject-names and then GETs the /versions/latest of each one
     *
     * Refreshes the CACHE object with latest subjects
     */
    refreshLatestSubjectsCACHE: function () {

      var deferred = $q.defer();
      var start = new Date().getTime();

      // 1. Get all subject names
      getSubjects().then(
        function success(allSubjectNames) {
          // 2. Get full details of subject's final versions
          var urlFetchLatestCalls = [];
          angular.forEach(allSubjectNames, function (subject) {
            urlFetchLatestCalls.push($http.get(SCHEMA_REGISTRY + '/subjects/' + subject + '/versions/latest'));
          });
          $q.all(urlFetchLatestCalls).then(function (latestSchemas) {
            CACHE = []; // Clean up existing cache - to replace with new one
            angular.forEach(latestSchemas, function (result) {
              var data = result.data;
              var cacheData = {
                version: data.version,  // version
                id: data.id,            // id
                schema: data.schema,    // schema - in String - schema i.e. {\"type\":\"record\",\"name\":\"User\",\"fields\":[{\"name\":\"name\",\"type\":\"string\"}]}
                Schema: JSON.parse(data.schema), // js type | name | doc | fields ...
                subjectName: data.subject
              };
              CACHE.push(cacheData);
            });
            $log.debug("  pipeline : get-latest-subjects-refresh-cache in [ " + (new Date().getTime() - start) + " ] msec");
            $rootScope.showSpinner = false;
            deferred.resolve(CACHE);
          });
        });

      return deferred.promise;

    },

    /**
     * Get one subject at a particular version
     */
    getSubjectAtVersion: function (subjectName, subjectVersion) {

      var deferred = $q.defer();

      // If it's easier to fetch it from cache
      var subjectFromCache = getFromCache(subjectName, subjectVersion);
      if (subjectFromCache != undefined) {
        deferred.resolve(subjectFromCache);
      } else {
        var start = new Date().getTime();
        getSubjectAtVersion(subjectName, subjectVersion).then(
          function success(subjectInformation) {
            //cache it
            var subjectInformationWithMetadata = {
              version: subjectInformation.version,
              id: subjectInformation.id,
              schema: subjectInformation.schema, // this is text
              Schema: JSON.parse(subjectInformation.schema), // this is json
              subjectName: subjectInformation.subject
            };
            $log.debug("  pipeline: " + subjectName + "/" + subjectVersion + " in [ " + (new Date().getTime() - start) + " ] msec");
            deferred.resolve(subjectInformationWithMetadata);
          },
          function errorCallback(response) {
            $log.error("Failure with : " + JSON.stringify(response));
          });
      }
      return deferred.promise;

    },

    /**
     * GETs the entire subject's history, by
     *
     * i. Getting all version
     * ii. Fetching each version either from cache or from HTTP GET
     */
    getSubjectHistory: function (subjectName) {

      var deferred = $q.defer();

      $log.info("Getting subject [ " + subjectName + "] history");
      var completeSubjectHistory = [];
      getSubjectsVersions(subjectName).then(
        function success(allVersions) {
          var urlCalls = [];
          angular.forEach(allVersions, function (version) {
            // If in cache
            var subjectFromCache = getFromCache(subjectName, version);
            if (subjectFromCache != undefined) {
              completeSubjectHistory.push(subjectFromCache);
            } else {
              urlCalls.push($http.get(SCHEMA_REGISTRY + '/subjects/' + subjectName + '/versions/' + version));
            }
          });
          // Get all missing versions and add them to cache
          $q.all(urlCalls).then(function (results) {
            angular.forEach(results, function (result) {
              completeSubjectHistory.push(result.data);
            });
            deferred.resolve(completeSubjectHistory);
          });
        },
        function failure(data) {
          deferred.reject("pdata=>" + data);
        });

      return deferred.promise;

    },

    /**
     * Get the history in a diff format convenient for rendering a ui
     */
    getSubjectHistoryDiff: function (subjectHistory) {
      var changelog = [];

      $log.info("Sorting by version..");
      var sortedHistory = UtilsFactory.sortByVersion(subjectHistory);
      for (var i = 0; i < sortedHistory.length; i++) {
        var previous = '';
        if (i > 0)
          previous = JSON.parse(sortedHistory[i - 1].schema);
        var changeDetected = {
          version: sortedHistory[i].version,
          id: sortedHistory[i].id,
          current: JSON.parse(sortedHistory[i].schema),
          previous: previous
        };
        changelog.push(changeDetected);
      }

      return changelog;
    }
  }

});

angularAPP.service('toastFactory', function ($rootScope, $mdToast, $window, $log) {

  var last = {
    bottom: false,
    top: true,
    left: false,
    right: true
  };

  var toastPosition = angular.extend({}, last);

  /* Public API of this factory*/
  this.getToastPosition = function () {
    this.sanitizePosition();

    return Object.keys(toastPosition)
      .filter(function (pos) {
        return toastPosition[pos];
      })
      .join(' ');
  };

  this.sanitizePosition = function () {
    var current = toastPosition;
    if (current.bottom && last.top) current.top = false;
    if (current.top && last.bottom) current.bottom = false;
    if (current.right && last.left) current.left = false;
    if (current.left && last.right) current.right = false;
    last = angular.extend({}, current);
  };

  this.showSimpleToast = function (message) {
    $mdToast.show(
      $mdToast.simple()
        .textContent(message)
        .position(this.getToastPosition())
        .hideDelay(2000)
    );
  };

  this.showSimpleToastToTop = function (message) {
    this.showSimpleToast(message);
    $window.scrollTo(0, 0);
  };

  this.showLongToast = function (message) {
    var last = this.getToastPosition();

    $mdToast.show(
      $mdToast.simple()
        .textContent(message)
        .position(last)
        .hideDelay(5000)
    );
    $window.scrollTo(0, 0);
  };

  this.showActionToast = function (message) {
    var toast = $mdToast.simple()
      .textContent(message)
      .action('DELETE')
      .highlightAction(true)
      //.highlightClass('md-accent')// Accent is used by default, this just demonstrates the usage.
      .position(this.getToastPosition())
      .hideDelay(2000);

    $mdToast.show(toast).then(function (response) {
      if (response == 'ok') {
        //alert('You clicked the \'UNDO\' action.');
      }
    });
  };

  this.hideToast = function () {
    $mdToast.hide();
  };

});
/**
 * Utils angularJS Factory
 */
angularAPP.factory('UtilsFactory', function ($log) {

  // Sort arrays by key
  function sortByKey(array, key, reverse) {
    return array.sort(function (a, b) {
      var x = a[key];
      var y = b[key];
      return ((x < y) ? -1 * reverse : ((x > y) ? 1 * reverse : 0));
    });
  }

  /* Public API */
  return {

    sortByKey: function (array, key, reverse) {
      return sortByKey(array, key, reverse);
    },
    sortByVersion: function(array) {
      var sorted = array.sort(function(a, b) {
        return a.version - b.version;
      });
      return sorted;
    },
    IsJsonString: function (str) {
      try {
        JSON.parse(str);
      } catch (e) {
        return false;
      }
      return true;
    }

  }

});
angularAPP.controller('SchemaRegistryConfigCtrl', function ($scope, $http, $log, SchemaRegistryFactory) {

  $log.info("Starting schema-registry controller : config ");
  $scope.schemaRegistryURL = SCHEMA_REGISTRY;
  $scope.config = {};
  $scope.connectionFailure = false;

  //Get the top level config
  SchemaRegistryFactory.getGlobalConfig().then(
    function success(config) {
      $scope.config = config;
    },
    function failure(response) {
      $log.error("Failure with : " + JSON.stringify(response));
      $scope.connectionFailure = true;
    });
});

angularAPP.controller('HomeCtrl', function ($log, SchemaRegistryFactory, toastFactory) {
  $log.info("Starting schema-registry controller - home");
  toastFactory.hideToast();
});
angularAPP.controller('SubjectListCtrl', function ($scope, $rootScope, $log, $mdMedia, SchemaRegistryFactory) {

  $log.info("Starting schema-registry controller : list ( initializing subject cache )");

  /**
   * Watch the 'newCreated' and update the subject-cache accordingly
   */
  $scope.$watch(function () {
    return $rootScope.newCreated;
  }, function (a) {
    if (a != undefined && a == true) {
      loadCache(); //When new is created refresh the list
      $rootScope.newCreated = false;
    }
  }, true);
  // listen for the event in the relevant $scope
  $scope.$on('newEvolve', function (event, args) {
    loadCache();
  });
  /**
   * Load cache by fetching all latest subjects
   */
  loadCache();
  function loadCache() {
    $rootScope.allSchemas = [];
    var promise = SchemaRegistryFactory.refreshLatestSubjectsCACHE();
    promise.then(function (cachedData) {
      $rootScope.allSchemas = cachedData;
    }, function (reason) {
      $log.error('Failed at loadCache : ' + reason);
    }, function (update) {
      $log.debug('Got notification: ' + update);
    });
  }

});

//In small devices the list is hidden
// $scope.$mdMedia = $mdMedia;
// $scope.$watch(function () {
//   return $mdMedia('gt-sm');
// }, function (display) {
//   $rootScope.showList = display;
// });

angularAPP.controller('NewSubjectCtrl', function ($scope, $route, $rootScope, $http, $log, $q, $location, UtilsFactory, SchemaRegistryFactory, toastFactory) {
  $log.debug("NewSubjectCtrl - initiating");

  $scope.noSubjectName = true;
  $rootScope.newCreated = false;
  toastFactory.hideToast();

  $scope.showSimpleToast = function (message) {
    toastFactory.showSimpleToast(message)
  };
  $scope.showSimpleToastToTop = function (message) {
    toastFactory.showSimpleToastToTop(message);
  };

  $scope.hideToast = function () {
    toastFactory.hide();
  };

  var self = this;

  self.simulateQuery = false;
  self.isDisabled = false;

  // list of `state` value/display objects
  self.states = loadAll();
  self.querySearch = querySearch;
  self.selectedItemChange = selectedItemChange;
  self.searchTextChange = searchTextChange;

  // ******************************
  // Internal methods
  // ******************************

  /**
   * Search ... use $timeout to simulate remote dataservice call.
   */
  function querySearch(query) {
    var results = query ? self.states.filter(createFilterFor(query)) : self.states,
      deferred;
    if (self.simulateQuery) {
      deferred = $q.defer();
      $timeout(function () {
        deferred.resolve(results);
      }, 10);
      return deferred.promise;
    } else {
      return results;
    }
  }

  function searchTextChange(text) {
    // $log.debug('subject name changed to ' + text);
    $scope.noSubjectName = ((text == undefined) || (text.length == 0));
    $scope.text = text;
    updateCurl();
  }

  function selectedItemChange(item) {
    // $log.debug('selected subject changed to ' + JSON.stringify(item));
    if (item != undefined && item.display != undefined) {
      $scope.text = item.display;
      updateCurl();
    }
  }

  /**
   * Build `states` list of key/value pairs
   */
  function loadAll() {
    $log.debug("Loading all subjects to auto-suggest subject names");
    // 1. Get all subject names
    $http.get(SCHEMA_REGISTRY + '/subjects/')
      .then(
        function successCallback(response) {
          var mainData = [];
          response.data.map(function (name) {
            var a = {
              value: name.toLowerCase(),
              display: name
            };
            mainData.push(a);
          });
          self.states = mainData;
        },
        function errorCallback(response) {
          $log.error("Failure with : " + response)
        });
  }

  /**
   * Create filter function for a query string
   */
  function createFilterFor(query) {
    var lowercaseQuery = angular.lowercase(query);
    return function filterFn(state) {
      return (state.value.indexOf(lowercaseQuery) === 0);
    };
  }

  /**
   * Possibilities
   * 1. no-subject-name -> User has not filled-in the subjectName
   * 2. not-json        -> Schema is invalid Json
   * 3. new-schema      -> Schema is Json + subject does not exist
   * 4. compatible      -> Schema is Json + subject already exists - and it's compatible
   * 5. non-compatible  -> Schema is Json + subject already exists - and it's not compatible
   * 6. failure         -> Connection failure
   */
  $scope.allowCreateOrEvolution = false;
  function testCompatibility(subject, newAvroString) {
    var deferred = $q.defer();
    if ((subject == undefined) || subject.length == 0) {
      $scope.showSimpleToastToTop("Please fill in the subject name"); // (1.)
      $scope.aceBackgroundColor = "white";
      deferred.resolve("no-subject-name");
    } else {
      if (!UtilsFactory.IsJsonString(newAvroString)) {
        $scope.showSimpleToastToTop("This schema is not valid Json"); // (2.)
        $scope.aceBackgroundColor = "rgba(255, 255, 0, 0.10)";
        deferred.resolve("not-json")
      } else {
        var latestKnownSubject = SchemaRegistryFactory.getLatestSubjectFromCache(subject);
        if (latestKnownSubject == undefined) {
          // (3.)
          $scope.createOrEvolve = "Create new schema";
          $scope.showSimpleToast("This will be a new Subject");
          $scope.allowCreateOrEvolution = true;
          $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
          deferred.resolve("new-schema")
        } else {
          SchemaRegistryFactory.testSchemaCompatibility($scope.text, $scope.newAvroString).then(
            function success(data) {
              $log.info("Success in testing schema compatibility " + data);
              // (4.)
              if (data == 'true') {
                $scope.createOrEvolve = "Evolve schema";
                $scope.allowCreateOrEvolution = true;
                $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
                $scope.showSimpleToast("Schema seems compatible");
                deferred.resolve("compatible")
              } else if (data == 'false') {
                // (5.)
                $scope.allowCreateOrEvolution = false;
                $scope.showSimpleToastToTop("Schema is NOT compatible");
                $scope.aceBackgroundColor = "rgba(255, 255, 0, 0.10)";
                deferred.resolve("non-compatible")
              } else if (data == 'new') {
                $scope.createOrEvolve = "Create new schema";
                $scope.allowCreateOrEvolution = true;
                $scope.showSimpleToast("This will be a new Subject");
                $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
                deferred.resolve("??")
              }
            },
            function failure(data) {
              $scope.showSimpleToastToTop("Failure with - " + data);
              deferred.resolve("failure");
            }
          );
        }
      }
    }

    return deferred.promise;
  }

  /**
   * Update curl to reflect  selected subject + schema
   */
  function updateCurl() {
    //$log.debug("Updating curl commands accordingly");
    var remoteSubject = "FILL_IN_SUBJECT";
    if (($scope.text != undefined) && $scope.text.length > 0) {
      remoteSubject = $scope.text;
    }

    var curlPrefix = 'curl -vs --stderr - -XPOST -i -H "Content-Type: application/vnd.schemaregistry.v1+json" --data ';
    $scope.curlCommand =
      "\n// Test compatibility\n" + curlPrefix +
      "'" + '{"schema":"' + $scope.newAvroString.replace(/\n/g, " ").replace(/\s\s+/g, ' ').replace(/"/g, "\\\"") +
      '"}' + "' " + SCHEMA_REGISTRY + "/compatibility/subjects/" + remoteSubject + "/versions/latest" +
      "\n\n" +
      "// Register new schema\n" + curlPrefix +
      "'" + '{"schema":"' + $scope.newAvroString.replace(/\n/g, " ").replace(/\s\s+/g, ' ').replace(/"/g, "\\\"") +
      '"}' + "' " + SCHEMA_REGISTRY + "/subjects/" + remoteSubject + "/versions";
  }

  /**
   * Private method to register-new-schema
   */
  function registerNewSchemaPrivate(newSubject, newAvro) {

    var deferred = $q.defer();

    SchemaRegistryFactory.registerNewSchema(newSubject, newAvro).then(
      function success(id) {
        $log.info("Success in registering new schema " + id);
        var schemaId = id;
        $scope.showSimpleToastToTop("Schema ID : " + id);
        $rootScope.newCreated = true; // trigger a cache re-load
        $location.path('/schema/' + newSubject + '/version/latest');
        deferred.resolve(schemaId);
      },
      function error(data, status) {
        $log.info("Error on schema registration : " + JSON.stringify(data));
        var errorMessage = data.message;
        $scope.showSimpleToastToTop(errorMessage);
        if (status >= 400) {
          $log.debug("Schema registrations is not allowed " + status + " " + data);
        } else {
          $log.debug("Schema registration failure: " + JSON.stringify(data));
        }
        deferred.reject(errorMessage);
      });

    return deferred.promise;

  }

  $scope.testCompatibility = function () {
    return testCompatibility($scope.text, $scope.newAvroString);
  };

  /**
   * How to responde to register new schema clicks
   */
  $scope.registerNewSchema = function () {
    var subject = $scope.text;
    testCompatibility(subject, $scope.newAvroString).then(
      function success(response) {
        // no-subject-name | not-json | new-schema | compatible | non-compatible | failure
        switch (response) {
          case "no-subject-name":
          case "not-json":
          case "failure":
          case "non-compatible":
            $log.debug("registerNewSchema - cannot do anything more with [ " + response + " ]");
            break;
          case 'new-schema':
            $log.debug("new-schema");
            registerNewSchemaPrivate(subject, $scope.newAvroString).then(
              function success(newSchemaId) {
                $log.info("New subject id after posting => " + newSchemaId);
              },
              function failure(data) {
                $log.error("peiler=>" + data);
              });
            break;
          case 'compatible':
            $log.info("Compatibility [compatible]");
            // TODO
            var latestKnownSubject = SchemaRegistryFactory.getLatestSubjectFromCache(subject);
            if (latestKnownSubject == undefined) {
              $log.error("This should never happen.")
            } else {
              $log.info("Existing schema id = " + latestKnownSubject.version);
              registerNewSchemaPrivate(subject, $scope.newAvroString).then(
                function success(newSchemaId) {
                  $log.info("New subject id after posting => " + newSchemaId);
                  if (latestKnownSubject.version == newSchemaId) {
                    toastFactory.showSimpleToastToTop("The schema you posted was same to the existing one")
                  }
                },
                function failure(data) {
                  $log.error("peiler=>" + data);
                });
              break;
            }
          default:
            $log.warn("Should never come here " + response);
        }
      },
      function failure(data) {
        $log.error("Could not test schema compatibility")
      });

  };

  // $scope.createOrEvolve = "Create new schema";
  // $scope.allowCreateOrEvolution = true;
  // $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";


  //   $http(postSchemaRegistration)
  //   $http.get(SCHEMA_REGISTRY + '/subjects/' + $scope.text + '/versions/latest')
  //     .success(function (data) {
  //       $log.info("Schema succesfully registered: " + JSON.stringify(data));
  //       $location.path('/subjects/' + data.subject + '/version/' + data.version);
  //     });
  // }

  // When the 'Ace' of the schema/new is loaded
  $scope.newSchemaAceLoaded = function (_editor) {
    $scope.editor = _editor;
    $scope.editor.$blockScrolling = Infinity;
    $scope.aceSchemaSession = _editor.getSession(); // we can get data on changes now
    var lines = $scope.newAvroString.split("\n").length;
    // TODO : getScalaFiles($scope.aceString);
    // Add one extra line for each command > 110 characters
    angular.forEach($scope.newAvroString.split("\n"), function (line) {
      lines = lines + Math.floor(line.length / 110);
    });
    if (lines <= 1) {
      lines = 10;
    }
    _editor.setOptions({
      minLines: lines + 1,
      maxLines: lines + 1,
      highlightActiveLine: false
    });
    updateCurl();
  };

  // When the 'Ace' of the schema/new is CHANGED (!)
  $scope.newSchemaAceChanged = function (_editor) {
    $scope.editor = _editor;
    updateCurl();
  };

  // When the 'Ace' of the curl command is loaded
  $scope.curlCommandAceLoaded = function (_editor) {
    $scope.editor = _editor;
    $scope.editor.$blockScrolling = Infinity;
  };


  $scope.newAvroString =
    angular.toJson(
      {
        "type": "record",
        "name": "evolution",
        "doc": "This is a sample Avro schema to get you started. Please edit",
        "namespace": "com.landoop",
        "fields": [{"name": "name", "type": "string"}, {"name": "number1", "type": "int"}, {
          "name": "number2",
          "type": "float"
        }]
      }, true);

});
angularAPP.controller('SubjectsCtrl', function ($rootScope, $scope, $route, $routeParams, $log, $location, SchemaRegistryFactory, UtilsFactory, toastFactory, Avro4ScalaFactory) {

  $log.info("Starting schema-registry controller: view ( " + $routeParams.subject + "/" + $routeParams.version + " )");
  toastFactory.hideToast();

  /**
   * At start-up - get the entire subject `History`
   */
  SchemaRegistryFactory.getSubjectHistory($routeParams.subject).then(
    function success(data) {
      $scope.completeSubjectHistory = SchemaRegistryFactory.getSubjectHistoryDiff(data);
      //$log.warn("Diff is:");
      //$log.warn(JSON.stringify($scope.completeSubjectHistory));
    }
  );

  /**
   * At start-up do something more ...
   */
  if ($routeParams.subject && $routeParams.version) {
    var promise = SchemaRegistryFactory.getSubjectAtVersion($routeParams.subject, $routeParams.version);
    promise.then(function (selectedSubject) {
      $log.info('Success fetching [' + $routeParams.subject + '/' + $routeParams.version + '] with MetaData');
      $rootScope.subjectObject = selectedSubject;
      $rootScope.schema = selectedSubject.Schema.fields;
      $scope.aceString = angular.toJson(selectedSubject.Schema, true);
      $scope.aceStringOriginal = $scope.aceString;
      $scope.aceReady = true;
      SchemaRegistryFactory.getSubjectsVersions($routeParams.subject).then(
        function success(allVersions) {
          var otherVersions = [];
          angular.forEach(allVersions, function (version) {
            if (version != $rootScope.subjectObject.version) {
              otherVersions.push(version);
            }
          });
          $scope.otherVersions = otherVersions;
          $scope.multipleVersionsOn = $scope.otherVersions.length > 0; // TODO remove
        },
        function failure(response) {
          // TODO
        }
      )
    }, function (reason) {
      $log.error('Failed: ' + reason);
    }, function (update) {
      $log.info('Got notification: ' + update);
    });
  }


  $scope.aceString = "";
  $scope.aceStringOriginal = "";
  $scope.multipleVersionsOn = false;

  $scope.isAvroUpdatedAndCompatible = false;
  $scope.testAvroCompatibility = function () {
    $log.debug("Testing Avro compatibility");
    if ($scope.aceString == $scope.aceStringOriginal) {
      toastFactory.showSimpleToastToTop("You have not changed the schema");
    } else {
      if (UtilsFactory.IsJsonString($scope.aceString)) {
        $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
        $log.debug("Edited schema is a valid json and is a augmented");
        SchemaRegistryFactory.testSchemaCompatibility($routeParams.subject, $scope.aceString).then(
          function success(result) {
            if (result) {
              $log.info("Schema is compatible");
              $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
              toastFactory.showSimpleToast("You can now evolve the schema");
              $scope.isAvroUpdatedAndCompatible = true;
            } else {
              $scope.aceBackgroundColor = "rgba(255, 255, 0, 0.10)";
              toastFactory.showLongToast("This schema is incompatible with the latest version");
            }
          },
          function failure() {
            $log.error("Could not test compatibility");
          }
        );
      } else {
        $scope.aceBackgroundColor = "rgba(255, 255, 0, 0.10)";
        toastFactory.showLongToast("Invalid Avro");
      }
    }
  };

  $scope.evolveAvroSchema = function () {
    if ($scope.aceString != $scope.aceStringOriginal &&
      UtilsFactory.IsJsonString($scope.aceString)) {
      SchemaRegistryFactory.testSchemaCompatibility($routeParams.subject, $scope.aceString).then(
        function success(result) {
          var latestSchema = SchemaRegistryFactory.getLatestSubjectFromCache($routeParams.subject);
          $log.warn("peiler ");
          $log.warn(latestSchema);
          var latestID = latestSchema.id;
          SchemaRegistryFactory.registerNewSchema($routeParams.subject, $scope.aceString).then(
            function success(schemaId) {
              $log.info("Latest schema ID was : " + latestID);
              $log.info("New    schema ID is  : " + schemaId);
              if (latestID == schemaId) {
                toastFactory.showSimpleToastToTop(" Schema is the same as latest ")
              } else {
                toastFactory.showSimpleToastToTop(" Schema evolved to ID: " + schemaId);
                $rootScope.$broadcast('newEvolve');
                $location.path('/schema/' + $routeParams.subject + '/version/latest');
                $route.reload();
              }
            },
            function failure(data) {
            }
          );
        },
        function failure(data) {

        }
      );
    } else {
      $scope.aceBackgroundColor = "rgba(255, 255, 0, 0.10)";
      toastFactory.showLongToast("Invalid Avro");
    }
  };

  $scope.isAvroAceEditable = false;
  $scope.aceBackgroundColor = "white";
  $scope.cancelEditor = function () {
    $log.info("Canceling editor");
    $scope.aceBackgroundColor = "white";
    toastFactory.hideToast();
    $log.info("Setting " + $scope.aceStringOriginal);
    $scope.isAvroAceEditable = false;
    $scope.isAvroUpdatedAndCompatible = false;
    $scope.aceString = $scope.aceStringOriginal;
    $scope.aceSchemaSession.setValue($scope.aceString);
  };
  $scope.toggleEditor = function () {
    $scope.isAvroAceEditable = !$scope.isAvroAceEditable;
    if ($scope.isAvroAceEditable) {
      toastFactory.showLongToast("You can now edit the schema");
      $scope.aceBackgroundColor = "rgba(0, 128, 0, 0.04)";
    } else {
      $scope.aceBackgroundColor = "white";
      toastFactory.hideToast();
    }
  };

  /************************* md-table ***********************/
  $scope.tableOptions = {
    rowSelection: false,
    multiSelect: false,
    autoSelect: false,
    decapitate: false,
    largeEditDialog: false,
    boundaryLinks: false,
    limitSelect: true,
    pageSelect: true
  };

  $scope.query = {
    order: 'name',
    limit: 100,
    page: 1
  };

  // This one is called each time - the user clicks on an md-table header (applies sorting)
  $scope.logOrder = function (a) {
    // $log.info("Ordering event " + a);
    sortSchema(a);
  };

  function sortSchema(type) {
    var reverse = 1;
    if (type.indexOf('-') == 0) {
      // remove the - symbol
      type = type.substring(1, type.length);
      reverse = -1;
    }
    // $log.info(type + " " + reverse);
    $scope.schema = UtilsFactory.sortByKey($scope.schema, type, reverse);
  }

  function getScalaFiles(xx) {
    var scala = Avro4ScalaFactory.getScalaFiles(xx);
    $log.error("SCALA-> " + scala);
  }

  /************************* md-table ***********************/
  $scope.editor;

  // When the 'Ace' schema/view is loaded
  $scope.viewSchemaAceLoaded = function (_editor) {
    // $log.info("me");
    $scope.editor = _editor;
    $scope.editor.$blockScrolling = Infinity;
    $scope.aceSchemaSession = _editor.getSession(); // we can get data on changes now
    var lines = $scope.aceString.split("\n").length;
    // TODO : getScalaFiles($scope.aceString);
    // Add one extra line for each command > 110 characters
    angular.forEach($scope.aceString.split("\n"), function (line) {
      lines = lines + Math.floor(line.length / 110);
    });
    if (lines <= 1) {
      lines = 10;
    }
    // $log.warn("Lines loaded for curl create connector -> " + lines + "\n" + $scope.curlCommand);
    _editor.setOptions({
      minLines: lines,
      maxLines: lines,
      highlightActiveLine: false
    });
    // var _renderer = _editor.renderer;
    // _renderer.animatedScroll = false;
  };

  // When the 'Ace' schema/view is CHANGED
  $scope.viewSchemaAceChanged = function (_editor) {
    $scope.editor = _editor;
    var aceString = $scope.aceSchemaSession.getDocument().getValue();
    // $log.warn("LOADED ....");
    // Highlight differences
    var Range = ace.require('ace/range').Range;
    // TODO !!!
    // $scope.aceSchemaSession.addMarker(new Range(2, 5, 4, 16), "ace_diff_new_line", "fullLine");
    $scope.aceString = aceString;
  };

}); //end of controller

// Useful for browsing through different versions of a schema
angularAPP.directive('clickLink', ['$location', function ($location) {
  return {
    link: function (scope, element, attrs) {
      element.on('click', function () {
        scope.$apply(function () {
          $location.path(attrs.clickLink);
        });
      });
    }
  }
}]);
